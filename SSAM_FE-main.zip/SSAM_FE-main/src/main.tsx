import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { App } from './App'
import { LanguageProvider } from './i18n'
import { tokenStorage } from './lib/storage'
import './index.css'

// Dọn sạch dữ liệu/token mock cũ trong trình duyệt (nếu từng chạy chế độ mock trước đây)
try {
  localStorage.removeItem('ssam.mockdb.v1')
  localStorage.removeItem('ssam.mockdb.v2')
  const token = tokenStorage.getAccessToken()
  if (token && token.startsWith('mock-token-')) {
    tokenStorage.clear()
  }
} catch {
  // ignore storage errors
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <LanguageProvider>
      <App />
    </LanguageProvider>
  </StrictMode>,
)
