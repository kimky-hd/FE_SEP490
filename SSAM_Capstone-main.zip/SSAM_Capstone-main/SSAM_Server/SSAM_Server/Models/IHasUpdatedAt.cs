namespace SSAM_Server.Models;

public interface IHasUpdatedAt
{
    DateTime UpdatedAt { get; set; }
}
