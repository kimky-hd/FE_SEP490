global using SSAM_Server.Interfaces.Repositories;
global using SSAM_Server.Interfaces.Security;
global using SSAM_Server.Interfaces.Services;
